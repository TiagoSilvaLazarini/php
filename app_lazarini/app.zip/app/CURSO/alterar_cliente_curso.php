<?php

include('../protect.php');
include('../conexao.php');
header("Content-type:text/html; charset=utf8");
if(isset($_GET['id_curso_cliente'])){
  $id_curso_cliente = $mysqli->real_escape_string($_GET['id_curso_cliente']);
}
$id_admin= $mysqli->real_escape_string( $_SESSION['id']);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet"  href="../CSS/style.css?v=<?php echo uniqid(); ?>">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
  <title>Lazarini Equipamentos</title>
</head>

<body>
  <header id="header">
    <a id="logo" href="../menu.php"><img src="../IMAGENS/logo.png"></a>
    <nav id="nav">
      <button aria-label="Abrir Menu" id="btn-mobile" aria-haspopup="true" aria-controls="menu" aria-expanded="false">Menu
        <span id="hamburger"></span>
      </button>
      <ul id="menu" role="menu">
        <li><a href="../CLIENTE/index.php">Clientes</a></li>
        <li><a href="../PRODUTO/index.php">Produtos</a></li>
        <li><a href="../CURSO/index.php">Cursos</a></li>
        <li><a href="../AGENDA/index.php">Agenda</a></li>
        <li><a href="../ADMINISTRADOR/index.php">Perfil</a></li>
      </ul>
    </nav>
  </header>
  <div id="faixa"></div>
  <script src="../CSS/script.js"></script>
    <script src="../CSS/mask.js"></script>

<div id="corpo-form-cad">
	<h1>Alterar cliente do curso</h1>
  <?php
//verificar se clicou no botao
if(isset($_POST['forma_pagamento']))
{
  $hash = $mysqli->real_escape_string($_POST['hash']);
	if($hash != $_SESSION['_token']){
		die("Esta requisição não pode ser feita novamente");
	}
  $preco_venda_curso = $mysqli->real_escape_string($_POST['preco_venda_curso']);
  $n_parcela = $mysqli->real_escape_string($_POST['n_parcela']);
  $forma_pagamento = $mysqli->real_escape_string($_POST['forma_pagamento']);
  $nome_aluno_curso = $mysqli->real_escape_string($_POST['nome_aluno_curso']);
  $email_aluno_curso = $mysqli->real_escape_string($_POST['email_aluno_curso']);
  $telefone_aluno_curso = $mysqli->real_escape_string($_POST['telefone_aluno_curso']);
	//verificando se todos os campos nao estao vazios
	if(!empty($preco_venda_curso) && !empty($n_parcela) && !empty($forma_pagamento)){

    $sql_code = "SELECT * FROM curso_cliente WHERE id_curso_cliente  = '$id_curso_cliente'";
    $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);
    $curso_cliente = $sql_query->fetch_assoc();
    $id_curso = $curso_cliente['id_curso'];
     $parcela_antiga = $curso_cliente['n_parcela'];
      
      if($n_parcela == $parcela_antiga){
        
      }else if($n_parcela > $parcela_antiga){
       for ($parcela = $parcela_antiga+1; $parcela <= $n_parcela; $parcela++) {

      			$sql_code = "INSERT INTO curso_parcela(id_curso_cliente, parcela, pago) VALUES ('$id_curso_cliente', '$parcela', 'pendente')";
				$sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);
     			} 
       
     }else if($n_parcela < $parcela_antiga){
       for ($parcela = $parcela_antiga; $n_parcela < $parcela; $parcela--) {

      			$sql_code = "DELETE FROM curso_parcela WHERE id_curso_cliente = '$id_curso_cliente' AND parcela = '$parcela'";
				$sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);
     			} 
     }
      
      
      

      $sql_code = "UPDATE curso_cliente SET preco_venda_curso='$preco_venda_curso', n_parcela='$n_parcela', forma_pagamento='$forma_pagamento',nome_aluno_curso='$nome_aluno_curso',email_aluno_curso='$email_aluno_curso',telefone_aluno_curso='$telefone_aluno_curso' WHERE id_curso_cliente = '$id_curso_cliente'";
      $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);
      mysqli_close($mysqli);
     $_SESSION['_token'] = hash('sha512',rand(100,1000));
        ?>
		<div id='msg_sucesso'>
			Alterado com sucesso! <a href="index.php"><strong>Ver todos os cursos!</strong></a></br>
            Ou <a href="view.php?id_curso=<?php echo $id_curso; ?>"><strong>Ver o curso!</strong></a>
		</div>
		<?php
	}else{
		?>
		<div class="msg_erro">
			Preencha todos os campos!
		</div>
		<?php
	}
}
include('../conexao.php');

    $sql_code = "SELECT * FROM curso_cliente cc INNER JOIN curso c ON c.id_curso = cc.id_curso WHERE cc.id_curso_cliente = '$id_curso_cliente'";
    $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);
    $curso_cliente = $sql_query->fetch_assoc();
    $id_cliente = $curso_cliente['id_cliente'];
    
if($_SESSION['tipo'] == "S"){
    $sql_code = "SELECT * FROM cliente WHERE id_cliente = '$id_cliente'";
 }else{
    $sql_code = "SELECT * FROM cliente WHERE id_cliente = '$id_cliente' AND id_administrador='$id_admin'";
 }

 $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);
 $cliente = $sql_query->fetch_assoc();
if($sql_query->num_rows > 0){?>
  	
	<form action="" method="POST">
  		<input type="text" value="<?php echo $curso_cliente['nome_curso']; ?>" disabled="true">
  		<input type="text" value="<?php $data=strtotime($curso['data_ini']);  echo date("d/m/Y",$data); ?>" disabled="true">
  		<input type="text" value="<?php echo $cliente['nome_cliente']; ?>" disabled="true">
      	<label for="preco_venda_curso">Preço pago pelo cliente</label>
		<input type="text" name="preco_venda_curso" value="<?php echo $curso_cliente['preco_venda_curso']; ?>" placeholder="Preço pago pelo cliente" maxlength="14"onKeyPress="MascaraGenerica(this, 'MOEDA');">
      	<label for="forma_pagamento">Forma de pagamento</label>
    	<select name="forma_pagamento" placeholder="Boleto" class="select">
    	<option><?php echo $curso_cliente['forma_pagamento']; ?></option>
    	<option>Dinheiro</option>
    	<option>Cartão</option>
        <option>Boleto</option>
        <option>Deposito</option>
        <option>A vista</option>
    	</select>
      	<label for="n_parcelas">Nº de parcelas</label>
    	<select name="n_parcela" placeholder="Numero de parcelas" class="select">
    	<option value="<?php echo $curso_cliente['n_parcela'] ?>"><?php echo $curso_cliente['n_parcela']."x parcelas"; ?></option>
    	<option value="1">1x parcela</option>
    	<option value="2">2x parcelas</option>
        <option value="3">3x parcelas</option>
        <option value="4">4x parcelas</option>
        <option value="5">5x parcelas</option>
        <option value="6">6x parcelas</option>
    	</select>
      <label>Dados do aluno</label>
      <label for="nome_aluno_curso">Nome do aluno</label>
      <input type="text" name="nome_aluno_curso" placeholder="Nome do aluno do curso" maxlength="150" value="<?php echo $curso_cliente['nome_aluno_curso']; ?>">
      <label for="email_aluno_curso">Email do aluno</label>
      <input type="text" name="email_aluno_curso" placeholder="Email do aluno do curso" maxlength="150" value="<?php echo $curso_cliente['email_aluno_curso']; ?>">
      <label for="telefone_aluno_curso">Celular do aluno</label>
      <input type="text" name="telefone_aluno_curso" placeholder="celular do aluno do curso" value="<?php echo $curso_cliente['telefone_aluno_curso']; ?>" maxlength="15"onKeyPress="MascaraGenerica(this, 'CELULAR');">

     

    <input type="hidden" name="hash" value="<?php echo $_SESSION['_token']; ?>">
	<input type="submit" value="ALTERAR" class="entrar">
	</form>
  	<a href="deletar_cliente_curso.php?id_curso_cliente=<?php echo $id_curso_cliente; ?>"><input type="submit" value="DELETAR" class="entrar"></a>
    <?php }else{
      ?>
			<div class="msg_erro">
				Você não tem altoridade para ver essa venda</br> ou essa venda não existe
      </div>
		<?php }?>
	
	</div>
	<div class="daw"></div>
</body>

</html>